## 1.0.0

- First release

## 1.0.1
- Fixed bug while entering the bazaar that caused the game to freeze