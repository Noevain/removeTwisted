# RemoveTwisted

This mod is fully server side,only the host need to have it, if you find twisted in your game ping @noevain in the RoR2 modding discord.

Remove the twisted elite type by making their cost to the director extremely high so that it doesnt spawn them, BEWARE: this will change how the director behaves and might causes less spawn on long runs, this solution is far from elegant so if anyone who's actually familiar with R2API can comes with a better one it'll probably be better but at least this works for now.